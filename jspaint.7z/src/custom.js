$('.file-menu-button').removeClass('hidden');

// var undo = $(E('div'))
//   .addClass('menu-contaier')
//   .html('<tbody><tr class="menu-row menu-item" tabindex="-1"><td class="menu-item-checkbox-area"></td><td class="menu-item-label"><span class="menu-hotkey">U</span>ndo</td><td class="menu-item-shortcut">Ctrl+Z</td><td class="menu-item-submenu-area"></td></tr></tbody>');

// $(".tools").append(undo);
